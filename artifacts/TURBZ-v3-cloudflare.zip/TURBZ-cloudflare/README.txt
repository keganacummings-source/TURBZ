TURBZ — Cloudflare Pages upload
Upload the contents of this folder (not the zip itself as a nested archive) to Pages.

music/
  Drop veil.ogg or veil.mp3 here before you upload, or add them later and redeploy.
  The game loops that track after the first click. If the file is missing, the hunt stays quiet.
  Optional names: shrine.ogg, tavern.ogg, title.ogg (the game currently looks for veil).

TURBZ API
  Sign-in, autosave, and live lobbies with other accounts need the published game server.
  A Pages-only host serves this client. Create or sign in on the published TURBZ app so the account, cloud save, and lobby codes work.
