TURBZ — Cloudflare Pages direct upload

Upload this zip in Pages → Create → Direct Upload.
index.html is at the root, so the zip itself is the site.

This build is the offline hunt. Progress stays in the browser (hunt and Witch Circle are separate saves).
Username login, cloud autosave, and live lobbies are not in this pack — they need the published TURBZ server.

music/
  Drop veil.ogg or veil.mp3 here and redeploy if you want the loop.
  If the file is missing, the hunt stays quiet.
