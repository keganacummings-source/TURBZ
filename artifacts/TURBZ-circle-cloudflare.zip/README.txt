TURBZ Cloudflare package
- public/ is the game (index.html, assets, music).
- worker.js serves those files. Anything under /api returns 501.
- wrangler.toml binds ASSETS to ./public.

This pack is the offline build. The hunt and the Witch Circle keep separate saves in the browser. A Circle game over wipes only the Circle. Username login, cloud autosave, and lobbies still need the published TURBZ server, which stores both saves on the same account. This worker does not run accounts.

Deploy from this folder:
  npx wrangler deploy
