TURBZ — Cloudflare Pages

Upload this folder as-is. No build step.
index.html is the game. _redirects keeps every path on that page.

music/
  Drop veil.ogg or veil.mp3 in this folder and re-upload.
  The hunt loops the first one it finds after you click the game.
  ogg is tried first, then mp3. If the file is missing, the game stays quiet.
